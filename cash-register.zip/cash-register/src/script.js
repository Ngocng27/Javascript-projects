
function itemsController($scope) {
  
  
  var discount_applied = false;
  $scope.cart =[];
  $scope.discount_row =[];
  
 //Populating lists 
 $scope.product_list = [
    {code: '0001', quantity: 2, price: 4.39,  name: 'Oranges', label: 'Oranges'},
    {code: '0002', quantity: 10, price: 8.45,  name: 'Bananas', label: 'Bananas'},
    {code: '0003', quantity: 5, price: 5.99,  name: 'Strawberry', label: 'Strawberry'},
    
];
  

 $scope.search_list = function(name, list){
  var item= [];
  for (var i in list) {
    if (name == list[i].name) {
      item = list[i];
      break;
    }
  }
  return item;
}
 

  $scope.select_product = function() {
    $scope.product = $scope.search_list($scope.inputed_product_name, $scope.product_list);
    $scope.product_cost = $scope.product.price;
  }
  
 
  $scope.select_quantity = function() {
    $scope.product.quantity = $scope.inputed_product_quantity;
  }
  
  
  $scope.add_to_cart = function () {
   if ($scope.product.name !=undefined && $scope.product.quantity > 0) {
     $scope.cart[$scope.cart.length] = $scope.product;
     $scope.product=undefined;
     $scope.inputed_product_name = "";
     $scope.product_cost = "";
     $scope.inputed_product_quantity = "";
   }
  }
  
  
  $scope.void_last_transaction = function() {
    $scope.cart.pop();
  }
  
  $scope.void_sale = function() {
  	$scope.cart = [];
    $scope.discount_row = [];
    $scope.product = undefined;
  }
  
  
  $scope.apply_discount = function() {
    if ($scope.purchasing_employee.name !=undefined) {
      $scope.discount_row[$scope.discount_row.length] = $scope.purchasing_employee;
      discount_applied = true;
    } 
  }
 
  
  $scope.total = function() {
    if ($scope.cart.length > 0) {
      var sum = 0;
    	for (var i in $scope.cart) {
      	sum += $scope.cart[i].price * $scope.cart[i].quantity;
      }
      var empDiscount = 0;
      if (discount_applied) {
      	empDiscount += $scope.discount_row[0].discount;
      }
      sum *= 1- empDiscount/100;
    }
    return sum;
  }
  
 }